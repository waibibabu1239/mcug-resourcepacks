#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

bool noShade(vec3 col) {
	// noShade = Flat Shading & Remove tint color
	// Color isolation
	// (col.r == 32/255) && (col.g == 36/255) && (col.b == 15/255) / #20240f / 2106383
	
	return (col.r == 0.12549019607) && (col.g == 0.14117647058) && (col.b == 0.05882352941);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
	
	
	
	// If noShadePreserveTint == false then use minecraft default shading
	// texelFetch is used for light maps 
	vertexColor = noShade(Color.rgb) ? texelFetch(Sampler2, UV2 / 16, 0) : minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0) ;
	
	
	
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
}
